﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface ICitizenInterface
    {
        public string Name { get; }
        public int Age { get; }
    }
}
