﻿using BorderControl.Contracts;
using BorderControl.Model;
using System;
using System.Collections.Generic;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<ICitizens> all = new List<ICitizens>();
            List<IRobotable> allRobots = new List<IRobotable>();
            
            string input = Console.ReadLine();

            while (input != "End")
            {
                string[] cmdArgs = input
                    .Split();

                if (cmdArgs[0] == "Citizen")
                {
                    Citizen citizen = new Citizen(cmdArgs[1], int.Parse(cmdArgs[2]), cmdArgs[3], cmdArgs[4]);

                    all.Add(citizen);
                }
                else if (cmdArgs[0] == "Robot")
                {
                    Robot robot = new Robot(cmdArgs[1], cmdArgs[2]);

                    allRobots.Add(robot);
                }
                else if (cmdArgs[0] == "Pet")
                {
                    Pet pet = new Pet(cmdArgs[1], cmdArgs[2]);

                    all.Add(pet);
                }

                input = Console.ReadLine();
            }

            string specificYear = Console.ReadLine();

            foreach (var item in all)
            {
                if (item.Birthdate.EndsWith(specificYear))
                {
                    Console.WriteLine(item.Birthdate);
                   
                }
            }
        }
    }
}
